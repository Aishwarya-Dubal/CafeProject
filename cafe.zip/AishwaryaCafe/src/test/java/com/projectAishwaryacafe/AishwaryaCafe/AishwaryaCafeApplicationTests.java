package com.projectAishwaryacafe.AishwaryaCafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AishwaryaCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
