package com.projectAishwaryacafe.AishwaryaCafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AishwaryaCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AishwaryaCafeApplication.class, args);
	System.out.println("......Cafe Start....");
	}

}
