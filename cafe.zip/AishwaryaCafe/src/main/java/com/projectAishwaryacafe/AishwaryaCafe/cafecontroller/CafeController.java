package com.projectAishwaryacafe.AishwaryaCafe.cafecontroller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.projectAishwaryacafe.AishwaryaCafe.model.Contact;
import com.projectAishwaryacafe.AishwaryaCafe.model.Sign;

@Controller
public class CafeController {
	
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("loginpage")
	public String login () {
		return "aishwarya";
	}

	
	@RequestMapping("aishwarya")
	public String logindb(Sign sign,Model mode) {
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();
		Sign dblogin =ss.get(Sign.class,sign.getEmail());
		String page="";
		String msg="";
		if(dblogin != null) {
			if(sign.getEmail().equals(dblogin.getEmail())) {
				msg="Already Registred Email";
				page="aishwarya";
				
			}else {
				ss.save(sign);
				t.commit();
				page="index";
			}
		}else {
			ss.save(sign);
			t.commit();
			page="index";
		}
		mode.addAttribute("msg",msg);
		return page;
	}
	

	@RequestMapping("indexpage")
	public String index() {
		return "index";
	}
    
	@RequestMapping("index")
	public String add(Contact contact,Model mode) {
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();
		Contact dbemail=ss.get(Contact.class, contact.getEmail());
		String page="index";
		String msg="";
		if(dbemail != null) {
			if(contact.getEmail().equals(dbemail.getEmail())) {
				msg="Already Registerd email";
			}else {
				ss.save(contact);
				t.commit();
			}
		}else {
			ss.save(contact);
			t.commit();
		}
		
		mode.addAttribute("msg",msg);
		return page;
	}
	
	
}

